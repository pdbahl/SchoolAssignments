/* 
 * File:   main.cpp
 * Author: pdb2657
 *
 * Created on January 22, 2015, 12:26 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    
    cout << "Good Grief! It actually compiled and ran!"<<endl;
    
    
    
    return 0;
}

