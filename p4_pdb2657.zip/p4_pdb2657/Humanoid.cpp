/* 
 * File:   Humanoid.cpp
 * Author: pdb2657
 * 
 * Created on April 16, 2015, 8:57 PM
 */

#include "Humanoid.h"

Humanoid::Humanoid(string homeWorld, string breaths, string food,int arms, int legs, int heads, int eyes, int ears):
        Animaloid(homeWorld,breaths,food,2,2,1,2,2){
     
}


