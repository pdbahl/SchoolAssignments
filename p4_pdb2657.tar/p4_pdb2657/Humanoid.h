/* 
 * File:   Humanoid.h
 * Author: pdb2657
 *
 * Created on April 16, 2015, 8:57 PM
 */
#include "Animaloid.h"
#ifndef HUMANOID_H
#define	HUMANOID_H


class Humanoid :public Animaloid {
public:
    Humanoid(string homeWorld, string breaths, string food,int arms, int legs, int heads, int eyes, int ears);
    

    
};

#endif	/* HUMANOID_H */

